package com.example.lista_interativa

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.lista_interativa.adapter.TaskAdapter
import com.example.lista_interativa.databinding.ActivityMainBinding
import com.example.lista_interativa.model.Task

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private val taskList = mutableListOf<Task>()
    private lateinit var adapter: TaskAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setupRecyclerView()
        setupListeners()
    }

    private fun setupRecyclerView() {
        adapter = TaskAdapter(
            onTaskClicked = { task ->
                // Atualiza o campo isCompleted
                val index = taskList.indexOfFirst { it.id == task.id }
                if (index != -1) {
                    taskList[index] = taskList[index].copy(isCompleted = !task.isCompleted)
                    adapter.submitList(taskList.toList())
                }
            },
            onDeleteClicked = { task ->
                // Remove da lista
                taskList.removeAll { it.id == task.id }
                adapter.submitList(taskList.toList())
            }
        )

        binding.recyclerViewTasks.layoutManager = LinearLayoutManager(this)
        binding.recyclerViewTasks.adapter = adapter
    }

    private fun setupListeners() {
        binding.buttonAddTask.setOnClickListener {
            val title = binding.editTextTaskTitle.text.toString().trim()
            if (title.isNotEmpty()) {
                val task = Task(title = title)
                taskList.add(task)
                adapter.submitList(taskList.toList())
                binding.editTextTaskTitle.text.clear()
            }
        }
    }
}