package com.example.lista_interativa.model

data class Task(
    val title: String,
    val id: Long = System.currentTimeMillis(),
    var isCompleted: Boolean = false
)